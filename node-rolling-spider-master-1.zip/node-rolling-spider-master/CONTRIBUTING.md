# Contributing

## Running the test suite

```js
$ git clone <git url>
$ cd <clone dir>
$ npm install
$ npm test
```

Funny story, as of right now we dont have any tests, they mainly live in the
`SamplesAndTools` directory for use with a real drone. Please, please, please if
you rock at test, help out!



### Fixing bugs

Bug fixes are always welcome. Please add a test!
