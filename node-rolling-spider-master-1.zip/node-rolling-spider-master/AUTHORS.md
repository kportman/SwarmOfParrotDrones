# The main collaborators of this library

* Jack Watson-Hamblin <info@fluffyjack.com>
* Chris Williams <voodootikigod@gmail.com>

# Contributors ordered by first contribution.

* DroneWorks <https://github.com/droneworks>
* Chris Taylor <christhebaron@gmail.com>
